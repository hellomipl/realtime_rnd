import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighlightSearchDirective } from '../directives/highlight-search.directive';


@NgModule({
  declarations: [HighlightSearchDirective],
  imports: [CommonModule],
  exports: [HighlightSearchDirective]
})
export class SharedModule { }