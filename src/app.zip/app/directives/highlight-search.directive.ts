import { Directive, ElementRef, Input, OnChanges, Renderer2 } from '@angular/core';
import { SearchService } from '../services/search.service';


@Directive({
  selector: '[appHighlightSearch]'
})
export class HighlightSearchDirective implements OnChanges {
  @Input() line: string ='';
  @Input() linetext: string ='';
  @Input() pageIndex: number=0;
  @Input() lineIndex: number=0;
  
  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private searchService: SearchService
  ) {}

  ngOnChanges() {
    this.highlightSearchTerm();
  }

  highlightSearchTerm() {
    const searchTerm = this.searchService.getSearchTerm();
    const lineText = this.elementRef.nativeElement.textContent;
    const regex = new RegExp(searchTerm, 'gi');

    if (searchTerm && lineText) {
      const highlightedText = lineText.replace(regex, (match:any) => `<span class="highlight">${match}</span>`);
      this.renderer.setProperty(this.elementRef.nativeElement, 'innerHTML', highlightedText);

      if (regex.test(lineText)) {
        this.searchService.addSearchResult(this.pageIndex, this.lineIndex);
      }
    } else {
      this.renderer.setProperty(this.elementRef.nativeElement, 'textContent', lineText);
    }
  }
}