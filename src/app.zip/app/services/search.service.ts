import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SearchService {
  private searchTerm: string = '';
  private searchResults: { pageIndex: number; lineIndex: number }[] = [];

  setSearchTerm(term: string) {
    this.searchTerm = term;
    this.searchResults = [];
  }

  getSearchTerm() {
    return this.searchTerm;
  }

  addSearchResult(pageIndex: number, lineIndex: number) {
    this.searchResults.push({ pageIndex, lineIndex });
  }

  getSearchResults() {
    return this.searchResults;
  }

  clearSearchResults() {
    this.searchResults = [];
  }
}