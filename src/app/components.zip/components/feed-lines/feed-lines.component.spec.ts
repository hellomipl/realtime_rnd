import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedLinesComponent } from './feed-lines.component';

describe('FeedLinesComponent', () => {
  let component: FeedLinesComponent;
  let fixture: ComponentFixture<FeedLinesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FeedLinesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FeedLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
