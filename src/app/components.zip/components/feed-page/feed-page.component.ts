import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FeedLinesComponent } from '../feed-lines/feed-lines.component';

@Component({
  selector: 'app-feed-page',
  standalone: true,
  imports: [CommonModule,FeedLinesComponent],
  templateUrl: './feed-page.component.html',
  styleUrl: './feed-page.component.scss'
})
export class FeedPageComponent {
  @Input() page: any;
  @Input() itemSize: number=0;
  @Input() showTimestamp: boolean=false;

 

  
}
